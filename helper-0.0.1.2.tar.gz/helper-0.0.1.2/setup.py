from setuptools import setup, find_packages

setup(
    name='helper',
    version='0.0.1.2',
    author='sqxy090123',
    author_email='sqx20150423@outlook.com',
    description='Description of your library',
    long_description='Longer description of your library',
    url='https://github.com/sqxy090123/helper',
    packages=find_packages(),
    install_requires=[
        'ast',
        'inspect',
        'hashlib',
        'requests',
        'bs4',
        'cryptography',
        'base64',
        
        'dependent',
    ],
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
    ],
    keywords='help',
    project_urls={
        'Bug Reports': 'https://github.com/sqxy090123/helper/issues',
        'Source': 'https://github.com/sqxy090123/helper',
    },
)